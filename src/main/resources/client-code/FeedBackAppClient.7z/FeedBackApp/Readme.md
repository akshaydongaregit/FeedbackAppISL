# Student Feedback System

Web Application Usefull to get feedback from colleage student.

## Built With
* [AngularJS](https://angularjs.org/) - JS framework for Single Page Application.
* [Spring](http://spring.io/) - Java Web Framework used for Restfull Services
* [Maven](https://maven.apache.org/) - Dependency Management

## Contributing


## Versioning

## Authors

* **Pradeep Rai** - *Who Created this Repo* - [Pradeep007Rai](https://github.com/Pradeep007Rai)
* **I dont Know** - *Going to collect requiremnt and all Very Important work to do by [259997] (https://github.com/259997)
* **Akshay Dongare** - *One who create this file* - [Akshaydongaregit](https://github.com/akshaydongaregit)

## License

  OpenSource Till Now Licence will 
## Acknowledgments

* Hat tip to anyone whose code was used
* @Pradeep - Edit Inspiration
* @Pradeep - Edit etc


## Getting Started

### Prerequisitess

### Installing

## Running the tests

## Deployment
