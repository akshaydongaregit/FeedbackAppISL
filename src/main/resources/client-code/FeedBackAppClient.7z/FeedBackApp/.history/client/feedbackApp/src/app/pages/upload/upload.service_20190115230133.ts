import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UploadService {

  constructor(private http: HttpClient) { }

  uploadClassesList(data: any): Observable<any> {
    const param = {
      'class_id' : data.CLASS_ID ,
        'class_name' : data.CLASS_NAME ,
        'is_active' : 1
    };
    const uri = 'http://localhost:8082/class/uploadClasses';
    console.log('uploading ' + param + '...');
    return this.http.post<any>(uri, param);
  }

  uploadStudentsList(data: any): Observable<any> {
    const param = {
      'class_id' : data.CLASS_ID ,
        'class_name' : data.CLASS_NAME ,
        'is_active' : 1
    };
    const uri = 'http://localhost:8082/class/uploadStudents';
    console.log('uploading ' + param + '...');
    return this.http.post<any>(uri, param);
  }
  uploadTeachersList(data: any): Observable<any> {
    const param = {
      'class_id' : data.CLASS_ID ,
        'class_name' : data.CLASS_NAME ,
        'is_active' : 1
    };
    const uri = 'http://localhost:8082/class/uploadTeachers';
    console.log('uploading ' + param + '...');
    return this.http.post<any>(uri, param);
  }
  uploadSujectsList(data: any): Observable<any> {
    const param = {
      'class_id' : data.CLASS_ID ,
        'class_name' : data.CLASS_NAME ,
        'is_active' : 1
    };
    const uri = 'http://localhost:8082/class/uploadSujects';
    console.log('uploading ' + param + '...');
    return this.http.post<any>(uri, param);
  }
  uploadQuestionsList(data: any): Observable<any> {
    const param = {
      'class_id' : data.CLASS_ID ,
        'class_name' : data.CLASS_NAME ,
        'is_active' : 1
    };
    const uri = 'http://localhost:8082/class/uploadQuestions';
    console.log('uploading ' + param + '...');
    return this.http.post<any>(uri, param);
  }

  uploadSubjTeachMappingList(data: any): Observable<any> {
    const param = {
      'class_id' : data.CLASS_ID ,
        'class_name' : data.CLASS_NAME ,
        'is_active' : 1
    };
    const uri = 'http://localhost:8082/upload/uploadSubjTeachMapping';
    console.log('uploading ' + param + '...');
    return this.http.post<any>(uri, param);
  }
}
