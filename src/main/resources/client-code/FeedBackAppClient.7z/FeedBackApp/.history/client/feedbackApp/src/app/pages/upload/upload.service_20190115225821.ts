import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UploadService {

  constructor(private http: HttpClient) { }

  uploadClassList(data: any): Observable<any> {
    const param = {
      'class_id' : data.CLASS_ID ,
        'class_name' : data.CLASS_NAME ,
        'is_active' : 1
    };
    const uri = 'http://localhost:8082/class/addClasses';
    console.log('uploading ' + param + '...');
    return this.http.post<any>(uri, param);

  }

}
