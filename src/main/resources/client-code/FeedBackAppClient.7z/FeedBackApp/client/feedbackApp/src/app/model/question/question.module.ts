export interface QuestionModule {
    questionId: number;
    question: string;
    answer: number;
 }
