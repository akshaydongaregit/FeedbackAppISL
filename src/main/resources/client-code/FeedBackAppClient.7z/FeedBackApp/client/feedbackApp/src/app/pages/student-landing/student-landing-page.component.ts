import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-landing-page',
  templateUrl: './student-landing-page.component.html',
  styleUrls: ['./student-landing-page.component.css']
})
export class StudentLandingPageComponent implements OnInit {
loading: boolean;
  constructor() { }

  ngOnInit() {
  }

}
