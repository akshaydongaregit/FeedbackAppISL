import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagenotfound-page',
  templateUrl: './pagenotfound-page.component.html',
  styleUrls: ['./pagenotfound-page.component.css']
})
export class PagenotfoundPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
